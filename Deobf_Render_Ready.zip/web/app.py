import os, subprocess, tempfile
from pathlib import Path
from flask import Flask, render_template, request, send_file, jsonify
BASE=Path(__file__).resolve().parent.parent
DEOBF=BASE/"Deobfuscator"/"deobf"/"deob.py"
app=Flask(__name__,template_folder="templates",static_folder="static")
ALLOWED={".lua",".luau",".txt"}
@app.get("/")
def index(): return render_template("index.html")
@app.post("/api/deobfuscate")
def deobfuscate():
    uploaded=request.files.get("file")
    if not uploaded or not uploaded.filename: return jsonify(error="Choose a Luau/Lua file first."),400
    suffix=Path(uploaded.filename).suffix.lower()
    if suffix not in ALLOWED: return jsonify(error="Only .lua, .luau, or .txt files are accepted."),400
    with tempfile.TemporaryDirectory(prefix="deobsite_") as td:
        inp=Path(td)/Path(uploaded.filename).name; outdir=Path(td)/"output"; outdir.mkdir(); uploaded.save(inp)
        cmd=["python",str(DEOBF),str(inp),"-o",str(outdir/inp.name)]
        mode=request.form.get("mode","auto")
        if mode in {"luraph_v15","ironbrew1","generic"}: cmd += ["--obfuscator",mode]
        if request.form.get("no_devirt")=="1": cmd.append("--no-devirt")
        if request.form.get("strings")=="1": cmd.append("--strings")
        try: proc=subprocess.run(cmd,cwd=str(DEOBF.parent),capture_output=True,text=True,timeout=120)
        except subprocess.TimeoutExpired: return jsonify(error="The job exceeded the 120 second web timeout."),408
        if proc.returncode!=0: return jsonify(error=(proc.stderr or proc.stdout or "Deobfuscation failed.")[-5000:]),422
        result=outdir/inp.name
        if not result.exists():
            candidates=list(outdir.glob("*"))
            if not candidates: return jsonify(error="No output was produced."),500
            result=candidates[0]
        final=Path(tempfile.mkstemp(prefix="deob_result_",suffix=".luau")[1]); final.write_bytes(result.read_bytes())
    return send_file(final,as_attachment=True,download_name=Path(uploaded.filename).stem+".deobf.luau",mimetype="text/plain")
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
