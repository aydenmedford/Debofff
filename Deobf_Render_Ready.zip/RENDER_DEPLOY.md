# Deploy DEOBF Web to Render

## Fastest method
1. Put this project in a GitHub repository.
2. On Render, choose **New → Blueprint** and select the repository.
3. Render will read `render.yaml` and create the web service.
4. Wait for the build to finish, then open the generated `onrender.com` URL.

## Important
The web app can only run the supplied deobfuscator's full processing pipeline if the required Luau executables are present in:

`Deobfuscator/deobf/bin/`

Do not commit proprietary or restricted binaries unless you have permission to redistribute them. If the binaries are private, add them through your deployment process or use a private build source.

## Manual Render settings
- Runtime: Python 3
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn web.app:app --bind 0.0.0.0:$PORT --workers 1 --timeout 180`
